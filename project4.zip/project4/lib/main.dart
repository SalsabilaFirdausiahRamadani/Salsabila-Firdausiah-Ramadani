import 'package:flutter/material.dart';
import 'dart:async';
import 'home.dart';
import 'signup.dart';


void main() {
  runApp(MaterialApp(
    home: LoginForm(),
  ));
}

TextEditingController getUser = new TextEditingController();
TextEditingController getPass = new TextEditingController();
final _formKey = GlobalKey<FormState>();

class LoginForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.pink[50],
        body: Column(
          key: _formKey,
          children: [
            SizedBox(
                height: MediaQuery.of(context).size.height * 0.2),
            Image.asset('images/logocantik.png',
              width: 170.0,
              height: 170.0,
              fit: BoxFit.cover,// Atur bagaimana gambar di-fit ke dalam kotak
            ),

            Text('HELLO',
            style: TextStyle(
              color: Colors.pink[400],
              fontSize: 32,
              letterSpacing: 4.0,
              fontWeight: FontWeight.bold),),
            SizedBox(height: 10),
            Text('Login For Exploring All About Beauty',
            style: TextStyle(
              color: Colors.pink[300],
            fontSize: 18,
            letterSpacing:1.0),),

            Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: getUser,
              cursorColor: Colors.pink[400],
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color:
                  Colors.pink, width: 2.0),
                  borderRadius:
                    BorderRadius.circular(50.0),
                ),
                contentPadding:
                    EdgeInsets.only(left: 30.0, top: 20.0,
                        bottom: 20.0 ),
                focusedBorder: OutlineInputBorder(
                  borderSide:
                    const BorderSide(color: Colors.pink,
                    width: 2.0),
                  borderRadius:
                    BorderRadius.circular(50.0),
                ),
                suffixIcon: Icon(
                  Icons.person,
                color: Colors.pink[400]
                ),
                labelText: ('Username'),
                labelStyle: TextStyle(
                  color: Colors.pink[400]
                ),
              ),
              validator: (value){
            if (value == null || value.isEmpty){
            return 'Please enter your Email';
            }
            return null;
            }
            ),
            ),

           Padding(
           padding: const EdgeInsets.all(8.0),
           child: TextFormField(
             controller: getPass,
              cursorColor: Colors.pink[400],
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.pink, width: 2.0),
                  borderRadius: BorderRadius.circular(50.0),
                ),
                contentPadding:
                EdgeInsets.only(left: 30.0, top: 20.0, bottom: 20.0),
                focusedBorder: OutlineInputBorder(
                  borderSide:
                  const BorderSide(color: Colors.pink, width: 2.0),
                  borderRadius: BorderRadius.circular(50.0),
                ),
                suffixIcon: Icon(
                  Icons.lock,
                  color: Colors.pink[400],
                ),

                labelText: ('Password'),
                  labelStyle:TextStyle(
                      color: Colors.pink[400]
                ),
              ),
             validator: (value){
               if (value == null || value.isEmpty){
                 return 'Please enter your Password';
               }
               return null;
             }
            ),
           ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Expanded(
                    child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // Navigate the user to the Home page
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please fill input')),
                      );
                    }
                    //nanti kita arahkan ke halaman daftar
                    Navigator.push(context, MaterialPageRoute(builder: (context) => signup()));
                  },
                  child: Text(
                    "Sign Up",
                    style: TextStyle(
                      letterSpacing: 2.0,
                      color: Colors.pink,
                      fontSize: 20),
                    ),
                  ),
                ),
             ),
                Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: Colors.pink,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          minimumSize: Size(150, 50), // Sesuaikan dengan ukuran yang Anda inginkan.
                        ),
                        onPressed: () {
                          // Nantikan aksi yang akan diambil saat tombol ditekan.
                        },
                        child: Text(
                          "Sign In",
                          style:TextStyle(
                              letterSpacing: 2,
                              color: Colors.white,
                              fontSize: 20),
                        ),
                      ),
                    ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  signup() {}
}
