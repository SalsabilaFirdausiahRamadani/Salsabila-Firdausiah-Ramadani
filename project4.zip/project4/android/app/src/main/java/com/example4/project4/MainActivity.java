package com.example4.project4;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
